<div class="row">
    <div class="col-md-12" id="load_analytics_body"></div>
</div>

<?php include "course_analytic_scripts.php"; ?>